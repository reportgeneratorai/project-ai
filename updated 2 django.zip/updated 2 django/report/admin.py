from django.contrib import admin
from .models import Prompt, Docx_file
# Register your models here.


admin.site.register(Prompt)
admin.site.register(Docx_file)


